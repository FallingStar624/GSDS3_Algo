# 스택

<img src="https://progress-bar.dev/6/?scale=8&title=progress&width=500&color=babaca&suffix=/8">

[문제집 링크](https://www.acmicpc.net/workbook/view/7309)

| 문제 분류  | 문제  |                          문제 제목                           | 정답 코드 |
| :--------: | :---: | :----------------------------------------------------------: | :-------: |
| 연습 문제  | 10828 |        [스택](https://www.acmicpc.net/problem/10828)         | [✅](BOJ_10828.cpp)  |
| 기본 문제✔ | 10773 |        [제로](https://www.acmicpc.net/problem/10773)         | [✅](BOJ_10773.cpp) |
| 응용 문제✔ | 1874  |      [스택 수열](https://www.acmicpc.net/problem/1874)       |  [✅](BOJ_1874.cpp)         |
| 응용 문제✔ | 2493  |          [탑](https://www.acmicpc.net/problem/2493)          | [✅](BOJ_2493.cpp)  |
| 응용 문제  | 6198  |   [옥상 정원 꾸미기](https://www.acmicpc.net/problem/6198)   |  [✅](BOJ_6198.cpp)  |
| 응용 문제  | 17298 |       [오큰수](https://www.acmicpc.net/problem/17298)        |  [✅](BOJ_3015.cpp) |
| 응용 문제  | 3015  |   [오아시스 재결합](https://www.acmicpc.net/problem/3015)    | [💔](BOJ_3015.cpp) |
| 응용 문제  | 6549  | [히스토그램에서 가장 큰 직사각형](https://www.acmicpc.net/problem/6549) |[💔](BOJ_6549.cpp)   |
