#include <iostream>

using namespace std;

int main(void) {
    cout << R"(\    /\)" << "\n";
    cout << R"( )  ( '))" << "\n";
    cout << R"((  /  ))" << "\n";
    cout << R"( \(__)|)";
    return 0;
}
