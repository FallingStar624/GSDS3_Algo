#include <iostream>

using namespace std;

int main(void) {
    cout << "Hello World!";
    return 0;
}
