# 배열

<img src="https://progress-bar.dev/8/?scale=8&title=progress&width=500&color=babaca&suffix=/8">

| 문제 분류  | 문제  |                        문제 제목                        |                코드                 |
| :--------: | :---: | :-----------------------------------------------------: | :---------------------------------: |
| 연습 문제  | 10808 |  [알파벳 개수](https://www.acmicpc.net/problem/10808)   | [:white_check_mark:](BOJ_10808.cpp) |
| 기본 문제✔ | 2577  |   [숫자의 개수](https://www.acmicpc.net/problem/2577)   | [:white_check_mark:](BOJ_2577.cpp)  |
| 기본 문제✔ | 1475  |     [방 번호](https://www.acmicpc.net/problem/1475)     | [:white_check_mark:](BOJ_1475.cpp)  |
| 기본 문제✔ | 3273  |   [두 수의 합](https://www.acmicpc.net/problem/3273)    | [:white_check_mark:](BOJ_3273.cpp)  |
| 기본 문제  | 10807 |   [개수 세기](https://www.acmicpc.net/problem/10807)    | [:white_check_mark:](BOJ_10807.cpp) |
| 기본 문제  | 13300 |    [방 배정](https://www.acmicpc.net/problem/13300)     | [:white_check_mark:](BOJ_13300.cpp) |
| 기본 문제  | 11328 |     [Strfry](https://www.acmicpc.net/problem/11328)     | [:white_check_mark:](BOJ_11328.cpp) |
| 기본 문제  | 1919  | [애너그램 만들기](https://www.acmicpc.net/problem/1919) | [:white_check_mark:](BOJ_1919.cpp)  |

