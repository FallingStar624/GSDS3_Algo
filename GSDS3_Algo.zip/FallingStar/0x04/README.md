# 연결 리스트

![100%](https://progress-bar.dev/3/?scale=3&title=progress&width=500&color=babaca&suffix=/3)

[문제집 링크](https://www.acmicpc.net/workbook/view/7308)

| 문제 분류  | 문제 |                       문제 제목                       |            정답 코드             |
| :--------: | :--: | :---------------------------------------------------: | :------------------------------: |
| 연습 문제  | 1406 |    [에디터](https://www.acmicpc.net/problem/1406)     | [✅](BOJ_1406.cpp) |
| 기본 문제✔ | 5397 |    [키로거](https://www.acmicpc.net/problem/5397)     | [✅](BOJ_5397.cpp) |
| 기본 문제✔ | 1158 | [요세푸스 문제](https://www.acmicpc.net/problem/1158) | [✅](BOJ_1158.cpp) |
