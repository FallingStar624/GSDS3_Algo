# [Gold IV] 이중 우선순위 큐 - 7662 

[문제 링크](https://www.acmicpc.net/problem/7662) 

### 성능 요약

메모리: 49016 KB, 시간: 1532 ms

### 분류

자료 구조(data_structures), 우선순위 큐(priority_queue), 트리를 사용한 집합과 맵(tree_set)

