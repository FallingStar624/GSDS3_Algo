# [Silver I] 영역 구하기 - 2583 

[문제 링크](https://www.acmicpc.net/problem/2583) 

### 성능 요약

메모리: 2104 KB, 시간: 0 ms

### 분류

너비 우선 탐색(bfs), 깊이 우선 탐색(dfs), 그래프 이론(graphs), 그래프 탐색(graph_traversal)

