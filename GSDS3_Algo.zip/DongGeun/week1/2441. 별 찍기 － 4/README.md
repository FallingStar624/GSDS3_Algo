# [Bronze III] 별 찍기 - 4 - 2441 

[문제 링크](https://www.acmicpc.net/problem/2441) 

### 성능 요약

메모리: 2020 KB, 시간: 0 ms

### 분류

구현(implementation)

### 문제 설명

<p><span class="s1">첫째</span> <span class="s1">줄에는</span> <span class="s1">별</span> N<span class="s1">개</span>, <span class="s1">둘째</span> <span class="s1">줄에는</span> <span class="s1">별</span> N-1<span class="s1">개</span>, ..., N<span class="s1">번째</span> <span class="s1">줄에는</span> <span class="s1">별</span> 1<span class="s1">개를</span> <span class="s1">찍는</span> <span class="s1">문제</span></p>

<p class="p1">하지만<span class="s1">, </span>오른쪽을<span class="s1"> </span>기준으로<span class="s1"> </span>정렬한<span class="s1"> </span>별<span class="s1">(</span>예제<span class="s1"> </span>참고<span class="s1">)</span>을<span class="s1"> </span>출력하시오<span class="s1">.</span></p>

### 입력 

 <p><span class="s1">첫째</span> <span class="s1">줄에</span> N(1 ≤ N ≤ 100)<span class="s1">이</span> <span class="s1">주어진다</span>.</p>

### 출력 

 <p>첫째<span class="s1"> </span>줄부터<span class="s1"> N</span>번째<span class="s1"> </span>줄까지<span class="s1"> </span>차례대로<span class="s1"> </span>별을<span class="s1"> </span>출력한다<span class="s1">.</span></p>

