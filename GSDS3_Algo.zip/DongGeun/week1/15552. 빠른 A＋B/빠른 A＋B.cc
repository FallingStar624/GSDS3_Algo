#include <bits/stdc++.h>
using namespace std;

    
int main(void) {
    cin.tie(NULL);
    ios::sync_with_stdio(false);
    int n;
    cin>>n;
    int a,b;
    for(int i = 0; i < n; i++) 
    {
        cin>>a>>b;
        cout<<a+b<<'\n';
    }
}