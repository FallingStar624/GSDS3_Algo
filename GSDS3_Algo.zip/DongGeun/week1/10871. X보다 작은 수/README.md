# [Bronze III] X보다 작은 수 - 10871 

[문제 링크](https://www.acmicpc.net/problem/10871) 

### 성능 요약

메모리: 2060 KB, 시간: 4 ms

### 분류

구현(implementation), 수학(math)

