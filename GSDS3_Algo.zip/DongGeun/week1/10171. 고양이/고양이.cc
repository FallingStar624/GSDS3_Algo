#include <iostream>
using namespace std;
int main(void)
{
    cout << "\\    /\\" << '\n';
    cout << " )  ( \')" << '\n';
    cout << "(  /  )\n";
    cout << " \\(__)|";
}