# [Bronze V] 고양이 - 10171 

[문제 링크](https://www.acmicpc.net/problem/10171) 

### 성능 요약

메모리: 2020 KB, 시간: 0 ms

### 분류

구현(implementation)

