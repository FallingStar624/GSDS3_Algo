# [Silver II] N과 M (12) - 15666 

[문제 링크](https://www.acmicpc.net/problem/15666) 

### 성능 요약

메모리: 2020 KB, 시간: 0 ms

### 분류

백트래킹(backtracking)

